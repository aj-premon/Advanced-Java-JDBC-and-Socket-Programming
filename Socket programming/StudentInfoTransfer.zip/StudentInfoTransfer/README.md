# Student Info Transfer System
## Java Socket Programming + Collections Assignment

---

## Project Structure

```
StudentInfoTransfer/
├── src/
│   ├── client/
│   │   └── StudentClient.java
│   └── server/
│       └── StudentServer.java
└── README.md
```

---

## What It Does

| Component | Role |
|-----------|------|
| **StudentClient** | Collects Student ID, Name, and Marks via Scanner, sends to server via Socket |
| **StudentServer** | Receives data, stores in `HashMap<Integer, Integer[]>` + `ArrayList<String>`, displays table |

### Collections Used (as required)
- `HashMap<Integer, Integer[]>` → stores Student ID mapped to their marks array
- `ArrayList<String>` → stores Student Names (parallel to IDs list)
- `ArrayList<Integer>` → tracks insertion order of Student IDs

---

## How to Compile & Run

### Step 1 — Compile the Server
```bash
cd src/server
javac StudentServer.java
```

### Step 2 — Compile the Client
```bash
cd src/client
javac StudentClient.java
```

### Step 3 — Run the Server (open Terminal 1)
```bash
cd src/server
java StudentServer
```
You should see:
```
========================================
   Student Info Transfer System - Server
========================================
[Server] Listening on port 5000...
```

### Step 4 — Run the Client (open Terminal 2)
```bash
cd src/client
java StudentClient
```

---

## Sample Session

### Client Terminal
```
========================================
   Student Info Transfer System - Client
========================================
[Connected] Connected to server at localhost:5000

--- Enter Student Details ---
Enter Student ID (integer): 101
Enter Student Name: Alice Tan
Enter Mark 1 (0-100): 85
Enter Mark 2 (0-100): 90
[Sent] Data sent to server: 101,Alice Tan,85,90
[Server] [ACK] Student record stored successfully. ID=101

Do you want to add another student? (yes/no): yes

--- Enter Student Details ---
Enter Student ID (integer): 102
Enter Student Name: Bob Lee
Enter Mark 1 (0-100): 72
Enter Mark 2 (0-100): 68
[Sent] Data sent to server: 102,Bob Lee,72,68
[Server] [ACK] Student record stored successfully. ID=102

Do you want to add another student? (yes/no): no
[Disconnected] Closing connection. Goodbye!
```

### Server Terminal
```
[Connected] Client connected: 127.0.0.1
[Received] ID: 101 | Name: Alice Tan | Marks: 85, 90
[Received] ID: 102 | Name: Bob Lee   | Marks: 72, 68
[Client] Client requested disconnect.

[Disconnected] Client disconnected.

========================================
         All Student Records
========================================
ID         Name                 Mark 1     Mark 2     Average
----------------------------------------------------------
101        Alice Tan            85         90         87.5
102        Bob Lee              72         68         70.0
========================================
```

---

## Key Concepts Used

### Socket Programming
```java
// Server side — waits for connections
ServerSocket serverSocket = new ServerSocket(5000);
Socket clientSocket = serverSocket.accept();

// Client side — connects to server
Socket socket = new Socket("localhost", 5000);
```

### Collections
```java
// HashMap: Student ID → Marks array
HashMap<Integer, Integer[]> studentMarks = new HashMap<>();
studentMarks.put(101, new Integer[]{85, 90});

// ArrayList: Student Names
ArrayList<String> studentNames = new ArrayList<>();
studentNames.add("Alice Tan");
```

### Data Transfer (over Socket)
```java
// Sending (Client)
PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
out.println("101,Alice Tan,85,90");

// Receiving (Server)
BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
String data = in.readLine(); // "101,Alice Tan,85,90"
```

---

## Requirements
- Java JDK 8 or higher
- Both programs must run on the same machine (localhost) or adjust SERVER_HOST in StudentClient.java
